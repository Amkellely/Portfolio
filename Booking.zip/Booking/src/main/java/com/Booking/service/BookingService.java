package com.Booking.service;

import com.Booking.model.BookingResult;
import com.Booking.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public List<BookingResult> search(String city, String state) {
        return bookingRepository.findByCityAndState(city, state);
    }
}