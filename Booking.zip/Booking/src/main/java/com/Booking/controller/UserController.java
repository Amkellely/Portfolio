package com.Booking.controller;

import com.Booking.model.User;
import com.Booking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserRepository userRepository;

    @Autowired
    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/user")
    public String showUserProfile(Model model) {
        // Загружаем данные пользователя из базы данных
        User user = userRepository.findById(1L).orElse(null); // Предполагается, что пользователь с id=1 существует

        // Проверяем, был ли найден пользователь
        if (user != null) {
            // Если пользователь найден, добавляем его данные в модель
            model.addAttribute("user", user);
        } else {
            // Если пользователь не найден, можно предпринять соответствующие действия, например, перенаправление на страницу ошибки
            return "error"; // Предполагается, что у вас есть страница ошибки с именем "error"
        }

        // Возвращаем имя представления (HTML-шаблона), который будет отображать профиль пользователя
        return "user";
    }
}
