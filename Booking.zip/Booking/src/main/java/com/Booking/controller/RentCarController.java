package com.Booking.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RentCarController {

    @GetMapping("/rentcar")
    public String showRentCarPage() {
        return "rentcar";
    }
}