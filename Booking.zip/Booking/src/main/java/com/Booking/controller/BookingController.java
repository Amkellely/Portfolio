package com.Booking.controller;

import com.Booking.model.BookingResult;
import com.Booking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @GetMapping("/search")
    public String searchResults(@RequestParam("city") String city,
                                @RequestParam("state") String state,
                                Model model) {
        List<BookingResult> searchResults = bookingService.search(city, state);
        model.addAttribute("searchResults", searchResults);
        return "searchresults"; // Верните имя шаблона Thymeleaf для страницы результатов
    }
}
