package com.Booking.controller;

import com.Booking.model.User;
import com.Booking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(User user, Model model) {
        User existingUser = userService.findByUsername(user.getUsername());
        if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
            User userFromDB = userService.findByUsername(user.getUsername());
            model.addAttribute("user", userFromDB);
            return "user"; // Перенаправляем пользователя в личный кабинет после успешного входа
        } else {
            model.addAttribute("error", "Неправильное имя пользователя или пароль");
            return "login";
        }
    }
}
