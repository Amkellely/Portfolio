package com.Booking.repository;

import com.Booking.model.BookingResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<BookingResult, Long> {

    List<BookingResult> findByCityAndState(String city, String state);
}